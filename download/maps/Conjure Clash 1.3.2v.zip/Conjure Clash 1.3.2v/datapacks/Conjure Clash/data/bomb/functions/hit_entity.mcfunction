#Mark the ray has having found an entity.

scoreboard players set #hit bomb.raycasting 1

#Running custom commands since the entity was found.

summon creeper ~ ~ ~ {FallFlying:0b,NoAI:1b,ExplosionRadius:5b,Fuse:0,ignited:0b}