#Mark the ray as having found a block.

scoreboard players set #hit bomb.raycasting 1

#Running custom commands since the block was found.

summon creeper ~ ~ ~ {FallFlying:0b,NoAI:1b,ExplosionRadius:5b,Fuse:0,ignited:0b}