#Running custom per-step commands.

particle dust 0.216 0.216 0.220 1 ~ ~ ~ 0 0 0 1 0 normal

#Check if an entity was detected.

execute if score #hit bomb.raycasting matches 0 positioned ~-0.05 ~-0.05 ~-0.05 as @e[type=#bomb:entities,tag=!bomb.test,dx=0,sort=nearest] run function bomb:check_hit_entity

#Run a function if a block was successfully detected.

execute unless block ~ ~ ~ #bomb:blocks run function bomb:hit_block
scoreboard players add #distance bomb.raycasting 1

#Advance forward and run the ray again if no entity and/or block was found.

execute if score #hit bomb.raycasting matches 0 if score #distance bomb.raycasting matches ..400 positioned ^ ^ ^0.1 run function bomb:ray