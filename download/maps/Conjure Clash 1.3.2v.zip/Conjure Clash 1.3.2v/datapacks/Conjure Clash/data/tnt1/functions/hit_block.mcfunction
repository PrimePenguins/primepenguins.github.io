#Mark the ray as having found a block.

scoreboard players set #hit tnt1 1

#Running custom commands since the block was found.

execute if score $event main matches 0..1 run summon tnt ~ ~ ~ {fuse:20,NoGravity:1b}
execute if score $event main matches 2 run summon tnt ~ ~ ~ {fuse:10,NoGravity:1b}
execute if score $event main matches 3.. run summon tnt ~ ~ ~ {fuse:20,NoGravity:1b}