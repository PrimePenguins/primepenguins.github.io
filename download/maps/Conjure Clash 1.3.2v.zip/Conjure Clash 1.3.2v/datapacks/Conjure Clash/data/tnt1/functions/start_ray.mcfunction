#Setting up the raycasting data.

tag @s add tnt1
tag @s add tntlaunch

scoreboard players set #hit tnt1 0
scoreboard players set #distance tnt1 0

#Activating the raycast. This function will call itself until it is done.
tag @s add wand.slot.1.cooldown
playsound minecraft:block.amethyst_block.resonate ambient @s ~ ~ ~ 3 2 1
scoreboard players remove @s mana 20
function tnt1:ray

#Raycasting finished, removing tag from the raycaster.

tag @s remove tnt1