summon creeper ~ ~ ~ {ExplosionRadius:10b,Fuse:0}

scoreboard players set #hit bomb.raycasting 1