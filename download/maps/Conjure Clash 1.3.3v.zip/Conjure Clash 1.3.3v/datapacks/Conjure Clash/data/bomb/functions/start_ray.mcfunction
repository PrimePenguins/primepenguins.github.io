#Setting up the raycasting data.
tag @s add wand.slot.1.cooldown
tag @s remove no.mana
scoreboard players remove @s mana 100
playsound minecraft:block.amethyst_block.resonate ambient @s ~ ~ ~ 3 2 1

tag @s add bomb.test
scoreboard players set #hit bomb.raycasting 0
scoreboard players set #distance bomb.raycasting 0

#Activating the raycast. This function will call itself until it is done.

execute at @s anchored eyes positioned ^ ^ ^.1 run function bomb:ray

#Raycasting finished, removing tag from the raycaster.

tag @s remove bomb.test