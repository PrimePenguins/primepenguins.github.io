tp @a 99967 12 99969
clear @a
say test mode!
tag @a remove item
scoreboard players set $active main 0
