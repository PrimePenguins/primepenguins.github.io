
function game:ingame/wands/wand_main
function game:ingame/item
function game:ingame/border

execute as @e[type=item,nbt={Item:{id:"minecraft:carrot_on_a_stick"}}] run data merge entity @s {PickupDelay:0}
execute as @e[type=item,nbt={Item:{id:"minecraft:warped_fungus_on_a_stick"}}] run data merge entity @s {PickupDelay:0}

function game:ingame/mana/mana_main
