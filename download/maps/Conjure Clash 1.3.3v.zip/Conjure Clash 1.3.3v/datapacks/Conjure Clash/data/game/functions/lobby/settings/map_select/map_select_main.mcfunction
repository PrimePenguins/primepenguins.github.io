setblock 70 19 -493 minecraft:lever[face=floor,facing=east]
execute if score $map main matches 0 run function game:lobby/settings/map_select/nether_select
execute if score $map main matches 1 run function game:lobby/settings/map_select/overworld_select
execute if score $map main matches 2 run function game:lobby/settings/map_select/winter_select
execute if score $map main matches 3 run function game:lobby/settings/map_select/classic_select
execute if score $map main matches 4 run function game:lobby/settings/map_select/random_select
scoreboard players add $map main 1
execute if score $map main matches 5.. run scoreboard players set $map main 0
