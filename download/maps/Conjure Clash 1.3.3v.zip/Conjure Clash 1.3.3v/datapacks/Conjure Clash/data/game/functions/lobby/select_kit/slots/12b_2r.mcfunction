scoreboard players set @s wand.slot.2 0
item replace entity @s enderchest.12 with green_dye{display:{Name:'[{"text":"Rocket Jump Wand ","italic":false,"color":"dark_red"},{"text":"- ","color":"blue"},{"text":"\\uE000 ","color":"white"},{"text":"200","color":"blue"}]',Lore:['[{"text":"Blast off!","italic":false}]']},CustomModelData:4}
clear @s green_dye
title @s actionbar [{"text":"ROCKET JUMP WAND ","color":"red"},{"text":"SELECTED","color":"yellow"}]

tag @s remove random.slot2