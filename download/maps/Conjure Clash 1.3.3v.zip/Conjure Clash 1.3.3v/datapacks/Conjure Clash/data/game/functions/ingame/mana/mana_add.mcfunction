execute if score $event main matches 0 run scoreboard players add @a[tag=!no.regen] mana 5
execute if score $event main matches 2.. run scoreboard players add @a[tag=!no.regen] mana 5
execute if score $event main matches 1 run scoreboard players add @a[tag=!no.regen] mana 10
scoreboard players reset $time mana