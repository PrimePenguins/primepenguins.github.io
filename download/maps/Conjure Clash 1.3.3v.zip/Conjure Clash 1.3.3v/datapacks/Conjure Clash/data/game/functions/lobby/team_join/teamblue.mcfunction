scoreboard players reset @s JoinBlue
team join Team1
title @s actionbar [{"text":"Joined","color":"yellow","bold":true},{"text":" Blue Team","color":"blue","bold":true}]
tag @s add inteam
clear @s blue_dye
item replace entity @s container.3 with minecraft:blue_dye{display:{Name:'[{"text":"Join Blue Team ","italic":false,"color":"blue"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}