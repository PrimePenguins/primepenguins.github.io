execute as @a[tag=random.slot1,tag=!item] store result score @s wand.slot.1 run random value 0..2
execute as @a[tag=random.slot2,tag=!item] store result score @s wand.slot.2 run random value 0..2
function game:ingame/wands/item/1r_give
function game:ingame/wands/item/2r_give
item replace entity @a[tag=!item,team=Team1] armor.head with white_dye{display:{Name:'{"text":"Wizard\'s Hat","color":"dark_purple","bold":true}'},HideFlags:1,CustomModelData:1,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]} 1
item replace entity @a[tag=!item,team=Team2] armor.head with white_dye{display:{Name:'{"text":"Wizard\'s Hat","color":"dark_purple","bold":true}'},HideFlags:1,CustomModelData:2,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]} 1
tag @a add item