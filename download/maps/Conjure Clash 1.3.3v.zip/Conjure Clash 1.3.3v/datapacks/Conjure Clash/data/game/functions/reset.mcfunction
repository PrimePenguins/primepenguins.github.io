function game:reset/reset_main

kill @e[type=item]
forceload add 18 -26 72 45
tag @a remove item
fill 59 53 -135 36 53 -114 light[level=15] replace air
scoreboard players set $event_time main 0
scoreboard players set $event main 0
kill @e[type=minecraft:boat]
function game:setting_reset
clear @a 

tag @a remove tnt.cooldown
tag @a remove rocket.cooldown
tag @a remove bomb.cooldown
tag @a remove no.mana