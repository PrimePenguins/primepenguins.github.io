

title @a actionbar ["",{"text":"MAP SELECTED: ","color":"yellow"},{"text":"OVERWORLD","color":"green"}]
place template map_select:overworld 73 17 -496
data merge entity @e[tag=map_select_text,limit=1] {text:'[{"text":"SELECTED MAP:","color":"yellow","bold":true},{"text":" OVERWORLD","color":"green"}]'}
scoreboard players display name selected.map info ["",{"text":"MAP:","bold":true,"color":"yellow"},{"text":" OVERWORLD","bold":true,"color":"green"}]
scoreboard players set $random main 0