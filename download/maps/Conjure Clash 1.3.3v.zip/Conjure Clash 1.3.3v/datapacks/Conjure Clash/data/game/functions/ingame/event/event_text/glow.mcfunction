scoreboard players set $event main 5
title @a title ["",{"text":"EVENT:","color":"yellow"},{"text":" Glowy","color":"dark_aqua"}]
title @a subtitle {"text":"You shine bright!","color":"yellow"}
