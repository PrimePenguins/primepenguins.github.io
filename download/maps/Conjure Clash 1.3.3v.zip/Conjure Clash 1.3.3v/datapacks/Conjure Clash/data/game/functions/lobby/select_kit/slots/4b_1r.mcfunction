scoreboard players set @s wand.slot.1 1
item replace entity @s enderchest.4 with green_dye{display:{Name:'[{"text":"BOMB WAND ","italic":false,"color":"dark_red"},{"text":"- ","color":"blue"},{"text":"\\uE000 ","color":"white"},{"text":"100","color":"blue"}]',Lore:['[{"text":"Instant Explosion, Shorter Range than TNT WAND.","italic":false}]']},CustomModelData:2}
clear @s green_dye
title @s actionbar [{"text":"BOMB WAND ","color":"red"},{"text":"SELECTED","color":"yellow"}]
tag @s remove random.slot1