scoreboard players set $wand_cooldown main 0
title @a actionbar ["",{"text":"WAND COOLDOWN: ","color":"yellow"},{"text":"OFF","color":"red"}]
execute as @e[tag=cooldown_text] run data merge entity @s {text:'[{"text":"COOLDOWN:","color":"gold","bold":true},{"text":"\\nOFF","color":"dark_red","bold":true}]'}
scoreboard players display name cooldown info ["",{"text":"WAND COOLDOWN:","bold":true,"color":"yellow"},{"text":" OFF","bold":true,"color":"dark_red"}]
setblock 53 19 -470 minecraft:spruce_button[facing=north]