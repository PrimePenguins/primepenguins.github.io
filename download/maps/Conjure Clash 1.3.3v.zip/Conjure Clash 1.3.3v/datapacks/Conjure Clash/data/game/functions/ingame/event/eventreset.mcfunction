scoreboard players set $event_time main 0
scoreboard players set $event main 0