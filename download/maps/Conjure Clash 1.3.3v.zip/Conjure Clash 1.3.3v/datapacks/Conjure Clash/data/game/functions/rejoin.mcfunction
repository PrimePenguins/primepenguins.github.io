tag @s remove check
tag @s remove ingame
tag @s remove death
team leave @s
scoreboard players set @s rejoin 0
clear @s
