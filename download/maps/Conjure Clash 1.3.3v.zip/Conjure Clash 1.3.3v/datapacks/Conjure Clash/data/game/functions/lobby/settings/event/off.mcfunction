scoreboard players set $event_active main 0
title @a actionbar ["",{"text":"EVENTS: ","color":"yellow"},{"text":"OFF","color":"red"}]
execute as @e[tag=event_text] run data merge entity @s {text:'[{"text":"EVENTS:","color":"gold","bold":true},{"text":"\\nOFF","color":"dark_red","bold":true}]'}
scoreboard players display name events info ["",{"text":"EVENTS:","bold":true,"color":"yellow"},{"text":" OFF","bold":true,"color":"dark_red"}]

setblock 55 19 -470 spruce_button[facing=north]