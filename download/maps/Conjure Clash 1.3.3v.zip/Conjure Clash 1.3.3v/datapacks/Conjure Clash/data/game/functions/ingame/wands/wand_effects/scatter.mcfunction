execute as @a[gamemode=!spectator] at @s run summon tnt ~ ~ ~ {fuse:10}

scoreboard players remove @s mana 100