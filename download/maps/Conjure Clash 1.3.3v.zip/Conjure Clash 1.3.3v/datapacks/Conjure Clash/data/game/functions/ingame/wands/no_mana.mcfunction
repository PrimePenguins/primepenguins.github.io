tag @s remove wand.slot.1.cooldown
tag @s remove wand.slot.2.cooldown
tag @s add no.mana
tag @s remove height.limit