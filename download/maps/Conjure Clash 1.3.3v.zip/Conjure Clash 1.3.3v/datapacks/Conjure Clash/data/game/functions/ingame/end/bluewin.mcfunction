tellraw @a {"text":"Blue has won this game!","bold":true,"color":"blue"}
advancement grant @a[team=Team2] only cc:lose
advancement grant @a[team=Team1] only cc:win
tellraw @a ["",{"text":"Winners: ","color":"#FFDA40"},{"selector":"@a[team=Team1]","color":"#FFDA40"}]
function game:ingame/end/esm