gamemode adventure @a
scoreboard players set $active main 0
tag @a remove death 
team leave @a
clear @a
effect clear @a
tp @a 64 18 -494
function game:reset
function game:setting_reset
item replace entity @a container.3 with minecraft:blue_dye{display:{Name:'[{"text":"Join Blue Team ","italic":false,"color":"blue"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}
item replace entity @a container.4 with minecraft:gray_dye{display:{Name:'[{"text":"Spectate ","italic":false,"color":"gray"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}
item replace entity @a container.5 with minecraft:red_dye{display:{Name:'[{"text":"Join Red Team ","italic":false,"color":"dark_red"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}
worldborder set 20000000
scoreboard objectives setdisplay sidebar info
execute if score $random main matches 1 run scoreboard players set $map main 0