scoreboard players set $event main 3
title @a title ["",{"text":"EVENT:","color":"yellow"},{"text":" Jumpy","color":"green"}]
title @a subtitle {"text":"You gain a jump boost!","color":"yellow"}