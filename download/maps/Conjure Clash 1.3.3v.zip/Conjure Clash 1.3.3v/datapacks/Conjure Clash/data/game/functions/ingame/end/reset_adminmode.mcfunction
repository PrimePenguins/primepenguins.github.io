fill 51 52 -115 51 52 -120 minecraft:black_stained_glass
fill 50 52 -120 42 52 -120 minecraft:black_stained_glass
fill 41 52 -120 41 52 -115 minecraft:black_stained_glass

fill 55 52 -128 52 52 -128 minecraft:black_stained_glass
fill 51 52 -128 51 52 -133 minecraft:black_stained_glass

fill 36 54 -124 37 54 -124 air
data merge block 44 53 -131 {front_text:{messages:['{"text":""}','{"text":"[NETHER]","color":"red","bold":true,"clickEvent":{"action":"run_command","value":"execute as @s[tag=admin] run function game:lobby/settings/map_select/nether_select"}}','{"text":""}','{"text":""}']}}
data merge block 46 53 -131 {front_text:{messages:['{"text":""}','{"text":"[CLASSIC]","color":"blue","bold":true,"clickEvent":{"action":"run_command","value":"execute as @s[tag=admin] run function game:lobby/settings/map_select/classic_select"}}','{"text":""}','{"text":""}']}}
data merge block 48 53 -131 {front_text:{messages:['{"text":""}','{"text":"[OVERWORLD]","color":"green","bold":true,"clickEvent":{"action":"run_command","value":"execute as @s[tag=admin] run function game:lobby/settings/map_select/overworld_select"}}','{"text":""}','{"text":""}']}}