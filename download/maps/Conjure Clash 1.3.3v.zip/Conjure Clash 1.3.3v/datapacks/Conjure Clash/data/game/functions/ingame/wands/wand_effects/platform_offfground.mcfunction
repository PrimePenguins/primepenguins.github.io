scoreboard players remove @s mana 50
summon marker ~ ~ ~ {Tags:["plat"]}
tag @s add wand.slot.2.cooldown
tag @s remove wand.slot.1.cooldown