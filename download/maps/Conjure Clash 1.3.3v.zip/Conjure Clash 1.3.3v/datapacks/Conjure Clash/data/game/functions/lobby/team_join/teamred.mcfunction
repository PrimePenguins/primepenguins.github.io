scoreboard players reset @s JoinRed
team join Team2
title @s actionbar [{"text":"Joined","color":"yellow","bold":true},{"text":" Red Team","color":"red","bold":true}]
tag @s add inteam
clear @s red_dye
item replace entity @s container.5 with minecraft:red_dye{display:{Name:'[{"text":"Join Red Team ","italic":false,"color":"dark_red"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}