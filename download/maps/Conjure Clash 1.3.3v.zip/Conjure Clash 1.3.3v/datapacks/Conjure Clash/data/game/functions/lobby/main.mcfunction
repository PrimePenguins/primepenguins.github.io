# Entity
execute store result score $team1 main if entity @a[team=Team1]
execute store result score $team2 main if entity @a[team=Team2]


# Login System Handeling
tp @a[tag=!check] 64 18 -494
gamemode adventure @a[tag=!check]
item replace entity @a[tag=!check] container.3 with minecraft:blue_dye{display:{Name:'[{"text":"Join Blue Team ","italic":false,"color":"blue"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}
item replace entity @a[tag=!check] container.4 with minecraft:gray_dye{display:{Name:'[{"text":"Spectate ","italic":false,"color":"gray"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}
item replace entity @a[tag=!check] container.5 with minecraft:red_dye{display:{Name:'[{"text":"Join Red Team ","italic":false,"color":"dark_red"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}
title @a[tag=!check] title {"text":"Conjure Clash","color":"yellow"}
title @a[tag=!check] subtitle ["",{"text":"Made By ","color":"yellow"},{"text":"TEAM CHROMATIC","color":"dark_aqua"}]
tag @a[tag=!check] add check
setworldspawn 64 18 -494
# Effect
effect give @a weakness infinite 10 true
# Settings 
function game:lobby/settings/settings_main
kill @e[type=item]
# Join Teams
execute as @a[tag=!build] unless entity @s[nbt={Inventory:[{id:"minecraft:red_dye",Slot:5b}]}] run function game:lobby/team_join/teamred
execute as @a[tag=!build] unless entity @s[nbt={Inventory:[{id:"minecraft:blue_dye",Slot:3b}]}] run function game:lobby/team_join/teamblue
execute as @a[tag=!build] unless entity @s[nbt={Inventory:[{id:"minecraft:gray_dye",Slot:4b}]}] run function game:lobby/team_join/spec

execute if block 52 26 -489 stone_button[powered=true] run function game:lobby/start_detect
execute if block 51 19 -470 minecraft:spruce_button[powered=true] run function game:lobby/rngteam
execute as @e[tag=socials] at @s run tp @s ~ ~ ~ ~1 ~

scoreboard players enable @a[tag=host] AdminMode
scoreboard players enable @a[tag=admin] AdminMode
team join admin @a[team=,tag=admin]
team join host @a[team=,tag=host]
tag @a[tag=!player_lobby] add player_lobby

tag @a[team=host] remove inteam
tag @a[team=admin] remove inteam
tag @a[team=] remove inteam

effect clear @a minecraft:levitation
effect clear @a minecraft:slow_falling
function game:lobby/select_kit/ender_chest_menu
kill @e[type=tnt]

execute as @e[tag=discord.interaction] if data entity @s interaction on target run tellraw @s ["",{"text":"Discord Invite","bold":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://discord.gg/PYkcNHCECm"}},{"text":" (Click On It)","bold":true,"color":"yellow"}]
execute as @e[tag=youtube.interaction] if data entity @s interaction on target run tellraw @s ["",{"text":"@ChromaticMC","bold":true,"underlined":true,"color":"red","clickEvent":{"action":"open_url","value":"https://www.youtube.com/@ChromaticMC"}},{"text":" (Click On It)","bold":true,"color":"yellow"}]
execute as @e[type=minecraft:interaction] at @s if data entity @s interaction run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1000 0 0
execute as @e[type=minecraft:interaction] if data entity @s interaction run data remove entity @s interaction

scoreboard players set @a[tag=!wand.check] wand.slot.1 0
scoreboard players set @a[tag=!wand.check] wand.slot.2 0
tag @a[tag=!wand.check] add wand.check