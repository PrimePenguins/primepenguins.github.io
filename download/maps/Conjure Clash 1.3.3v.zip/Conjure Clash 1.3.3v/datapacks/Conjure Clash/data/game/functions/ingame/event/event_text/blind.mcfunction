scoreboard players set $event main 6
title @a title ["",{"text":"EVENT:","color":"yellow"},{"text":" I'm BLIND","color":"dark_aqua"}]
title @a subtitle {"text":"Uh Oh, you got some ink!","color":"yellow"}