tellraw @a {"text":"Both teams have tied!","bold":true,"color":"gray"}
function game:ingame/end/esm
advancement grant @a only cc:tie