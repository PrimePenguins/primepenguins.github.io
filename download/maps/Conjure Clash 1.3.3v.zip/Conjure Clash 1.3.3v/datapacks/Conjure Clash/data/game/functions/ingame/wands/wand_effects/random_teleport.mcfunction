 spreadplayers ~ ~ 20 30 false @s
 scoreboard players remove @s mana 100

tag @s add wand.slot.2.cooldown
tag @s remove wand.slot.1.cooldown