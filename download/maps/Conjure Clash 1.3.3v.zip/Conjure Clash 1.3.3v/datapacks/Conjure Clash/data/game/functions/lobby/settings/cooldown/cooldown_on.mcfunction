scoreboard players set $wand_cooldown main 1
title @a actionbar ["",{"text":"WAND COOLDOWN: ","color":"yellow"},{"text":"ON","color":"green"}]
execute as @e[tag=cooldown_text] run data merge entity @s {text:'[{"text":"COOLDOWN:","color":"gold","bold":true},{"text":"\\nON","color":"green","bold":true}]'}
scoreboard players display name cooldown info ["",{"text":"WAND COOLDOWN:","bold":true,"color":"yellow"},{"text":" ON","bold":true,"color":"green"}]
setblock 53 19 -470 minecraft:spruce_button[facing=north]