advancement grant @a[team=Team1] only cc:lose
advancement grant @a[team=Team2] only cc:win
#############################################
tellraw @a {"text":"Red has won this game!","bold":true,"color":"red"}
tellraw @a ["",{"text":"Winners: ","color":"#FFDA40"},{"selector":"@a[team=Team2]","color":"#FFDA40"}]
function game:ingame/end/esm