scoreboard players set $event main 1
title @a title ["",{"text":"EVENT:","color":"yellow"},{"text":" 2x Mana","color":"dark_aqua"}]
title @a subtitle {"text":"You get 2x more mana","color":"yellow"}