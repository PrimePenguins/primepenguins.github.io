# Main System
execute if score $active main matches 1 run function game:ingame/main
execute if score $active main matches 0 run function game:lobby/main
# Effects
effect give @a minecraft:saturation infinite 255 true
effect give @a minecraft:resistance infinite 255 true
# Extras
function game:adv/main
function game:adv/tag
execute as @a[tag=!build] if score @s rejoin matches 1.. run function game:rejoin
# Death MSG
scoreboard players add @a DeathMSG 1
scoreboard players set @a[scores={DeathMSG=21..}] DeathMSG 0

forceload add 58 -134 36 -114