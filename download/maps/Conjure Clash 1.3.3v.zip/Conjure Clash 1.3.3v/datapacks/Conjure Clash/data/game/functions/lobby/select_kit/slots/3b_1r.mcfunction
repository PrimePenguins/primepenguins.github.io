scoreboard players set @s wand.slot.1 0
item replace entity @s enderchest.3 with green_dye{display:{Name:'[{"text":"TNT WAND ","italic":false,"color":"dark_red"},{"text":"- ","color":"blue"},{"text":"\\uE000 ","color":"white"},{"text":"20","color":"blue"}]',Lore:['[{"text":"You can summon TNT!","italic":false}]']},CustomModelData:1}
clear @s green_dye
title @s actionbar [{"text":"TNT WAND ","color":"red"},{"text":"SELECTED","color":"yellow"}]
tag @s remove random.slot1