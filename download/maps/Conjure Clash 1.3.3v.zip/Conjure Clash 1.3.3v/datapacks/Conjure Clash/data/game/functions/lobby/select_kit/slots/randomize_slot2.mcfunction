tag @s add random.slot2
item replace entity @s enderchest.15 with green_dye{display:{Name:'[{"text":"??? ","italic":false,"color":"dark_red"},{"text":"- ","color":"blue"},{"text":"\\uE000 ","color":"white"},{"text":"???","color":"blue"}]',Lore:['[{"text":"???","italic":false}]']},CustomModelData:7}
clear @s green_dye
title @s actionbar [{"text":"??? ","color":"red"},{"text":"SELECTED","color":"yellow"}]