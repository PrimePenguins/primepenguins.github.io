tag @s remove wand.slot.1.cooldown
tag @s remove wand.slot.2.cooldown
tag @s remove no.mana
tag @s add height.limit