
title @a actionbar ["",{"text":"MAP SELECTED: ","color":"yellow"},{"text":"CLASSIC","color":"blue"}]
place template map_select:classic 73 17 -496
data merge entity @e[tag=map_select_text,limit=1] {text:'[{"text":"SELECTED MAP:","color":"yellow","bold":true},{"text":" CLASSIC","color":"blue"}]'}
scoreboard players display name selected.map info ["",{"text":"MAP:","bold":true,"color":"yellow"},{"text":" CLASSIC","bold":true,"color":"blue"}]
scoreboard players set $random main 0