tag @s add wand.slot.2.cooldown
tag @s remove wand.slot.1.cooldown
particle minecraft:explosion ~ ~ ~ 1 1 1 1 5
effect give @s minecraft:levitation 1 20 true
effect give @s minecraft:speed 1 1 true
effect give @s minecraft:slow_falling 3 2 true
scoreboard players remove @s mana 200
advancement grant @s[predicate=game:clutch_achiv] only cc:clutch

playsound minecraft:block.campfire.crackle ambient @s ~ ~ ~ 3 2 1