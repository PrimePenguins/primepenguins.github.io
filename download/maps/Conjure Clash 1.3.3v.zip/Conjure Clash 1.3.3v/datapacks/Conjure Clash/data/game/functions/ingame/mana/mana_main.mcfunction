scoreboard players add $time mana 1

execute as @a[gamemode=!spectator] run function game:ingame/mana/mana_text/not_used_mana
execute as @a[gamemode=!spectator] run function game:ingame/mana/mana_text/used_mana

execute as @a[gamemode=!spectator] if score @s mana >= #max_mana mana run tag @s add no.regen
execute as @a[gamemode=!spectator] if score @s mana < #max_mana mana run tag @s[tag=no.regen] remove no.regen
execute as @a[gamemode=!spectator] if score @s mana > #max_mana mana run scoreboard players operation @s mana = #max_mana mana

execute if score $time mana matches 5.. run function game:ingame/mana/mana_add
