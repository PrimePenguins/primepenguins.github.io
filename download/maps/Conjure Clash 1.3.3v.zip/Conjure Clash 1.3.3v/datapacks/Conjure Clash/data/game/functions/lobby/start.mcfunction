tp @a[team=Team1] 69 30 9
tp @a[team=Team2] 25 30 9
scoreboard players set $active main 1
gamemode survival @a
setblock 52 26 -489 stone_button[facing=north]
gamemode spectator @a[team=]
gamemode spectator @a[team=admin]

execute if score $random main matches 1 store result score $map main run random value 1..4
function game:reset
effect clear @a 
scoreboard players operation @a mana = #max_mana mana
tp @a[team=] 45 55 18
tp @a[team=admin] 45 55 18

kill @e[type=item]
kill @e[type=boat]
kill @e[type=tnt]

tag @a remove player_lobby
tag @a remove bomb.cooldown
tag @a remove tnt.cooldown
tag @a remove rocket.cooldown
worldborder set 71
scoreboard objectives setdisplay sidebar

tag @s remove reset.wand
