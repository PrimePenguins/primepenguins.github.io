# Order Of Maps: Classic, Nether, Overworld, Winter
execute if score $map main matches 4 run clone 164 54 -100092 223 103 -100021 18 22 -26
execute if score $map main matches 1 run clone 164 53 -99937 223 103 -99866 18 22 -26 
execute if score $map main matches 2 run clone 164 53 -100014 223 103 -99943 18 22 -26
execute if score $map main matches 3 run clone 164 53 -99859 223 103 -99788 18 22 -26