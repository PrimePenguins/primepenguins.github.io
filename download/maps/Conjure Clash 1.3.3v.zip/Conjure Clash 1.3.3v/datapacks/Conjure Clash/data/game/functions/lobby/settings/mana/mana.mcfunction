execute if score #max_mana mana matches 500..2500 run scoreboard players add #max_mana mana 50
execute if score #max_mana mana matches 2501.. run scoreboard players set #max_mana mana 500
title @a actionbar ["",{"text":"MAX MANA: ","color":"yellow"},{"score":{"name":"#max_mana","objective":"mana"},"color":"dark_aqua"}]
execute as @e[tag=mana_text] run data merge entity @s {text:'[{"text":"MAX MANA:\\n","color":"gold","bold":true},{"score":{"name":"#max_mana","objective":"mana"},"color":"dark_aqua"}]'}

setblock 57 19 -470 minecraft:spruce_button[facing=north]
data modify storage cc:space macros set value {}
execute store result storage cc:space macros.value int 1 run scoreboard players get #max_mana mana
function game:lobby/settings/mana/scoreboard with storage cc:space macros