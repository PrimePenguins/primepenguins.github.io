title @a actionbar ["",{"text":"MAP SELECTED: ","color":"yellow"},{"text":"NETHER","color":"red"}]
place template map_select:nether 73 17 -496
data merge entity @e[tag=map_select_text,limit=1] {text:'[{"text":"SELECTED MAP:","color":"yellow","bold":true},{"text":" NETHER","color":"red"}]'}
scoreboard players display name selected.map info ["",{"text":"MAP:","bold":true,"color":"yellow"},{"text":" NETHER","bold":true,"color":"red"}]
scoreboard players set $random main 0