scoreboard players set @s wand.slot.2 1
item replace entity @s enderchest.13 with green_dye{display:{Name:'[{"text":"Random Teleport Wand ","italic":false,"color":"dark_red"},{"text":"- ","color":"blue"},{"text":"\\uE000 ","color":"white"},{"text":"100","color":"blue"}]',Lore:['[{"text":"Teleport to an random location in a 20-30 block distance.","italic":false}]']},CustomModelData:5}
clear @s green_dye
title @s actionbar [{"text":"RANDOM TELEPORT WAND ","color":"red"},{"text":"SELECTED","color":"yellow"}]

tag @s remove random.slot2