scoreboard players set @s wand.slot.1 2
item replace entity @s enderchest.5 with green_dye{display:{Name:'[{"text":"Seeking TNT Wand ","italic":false,"color":"dark_red"},{"text":"- ","color":"blue"},{"text":"\\uE000 ","color":"white"},{"text":"100","color":"blue"}]',Lore:['[{"text":"Summon a TNT at EVERYONE! ","italic":false}]']},CustomModelData:3}
clear @s green_dye
title @s actionbar [{"text":"SEEKING TNT WAND ","color":"red"},{"text":"SELECTED","color":"yellow"}]
tag @s remove random.slot1