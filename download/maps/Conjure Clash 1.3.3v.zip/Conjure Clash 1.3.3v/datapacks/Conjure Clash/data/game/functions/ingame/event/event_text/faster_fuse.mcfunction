scoreboard players set $event main 2
title @a title ["",{"text":"EVENT:","color":"yellow"},{"text":" TNT FUSE","color":"red"}]
title @a subtitle {"text":"TNT explosion timer is shorter!","color":"yellow"}