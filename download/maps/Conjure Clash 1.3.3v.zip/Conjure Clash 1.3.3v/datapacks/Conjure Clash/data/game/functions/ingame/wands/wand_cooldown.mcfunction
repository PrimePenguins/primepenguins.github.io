function game:ingame/wands/rows/1r_cooldown
function game:ingame/wands/rows/2r_cooldown