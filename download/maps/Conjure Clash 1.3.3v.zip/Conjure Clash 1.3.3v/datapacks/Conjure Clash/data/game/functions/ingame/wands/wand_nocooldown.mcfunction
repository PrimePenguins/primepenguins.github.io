function game:ingame/wands/rows/2r_no_cooldown
function game:ingame/wands/rows/1r_no_cooldown
