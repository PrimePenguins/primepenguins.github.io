title @a actionbar ["",{"text":"MAP SELECTED: ","color":"yellow"},{"text":"???","color":"gray"}]
place template map_select:random 73 17 -496
data merge entity @e[tag=map_select_text,limit=1] {text:'[{"text":"SELECTED MAP:","color":"yellow","bold":true},{"text":" ???","color":"gray"}]'}
scoreboard players display name selected.map info ["",{"text":"MAP:","bold":true,"color":"yellow"},{"text":" ???","bold":true,"color":"gray"}]
scoreboard players set $random main 1
