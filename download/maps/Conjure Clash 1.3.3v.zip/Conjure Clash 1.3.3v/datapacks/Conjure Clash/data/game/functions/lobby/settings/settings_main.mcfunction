# Events
execute if block 55 19 -470 spruce_button[powered=true] if score $event_active main matches 0 run function game:lobby/settings/event/on
execute if block 55 19 -470 spruce_button[powered=true] if score $event_active main matches 1 run function game:lobby/settings/event/off
# Cooldown
execute if block 53 19 -470 minecraft:spruce_button[powered=true] if score $wand_cooldown main matches 0 run function game:lobby/settings/cooldown/cooldown_on
execute if block 53 19 -470 minecraft:spruce_button[powered=true] if score $wand_cooldown main matches 1 run function game:lobby/settings/cooldown/cooldown_off
# Mana
execute if block 57 19 -470 minecraft:spruce_button[powered=true] run function game:lobby/settings/mana/mana

execute if block 70 19 -493 minecraft:lever[powered=true] run function game:lobby/settings/map_select/map_select_main