gamemode spectator @s
function game:ingame/deathmsg
tp @s 46.00 55.69 13.81
scoreboard players reset @s death
tag @s add death
advancement grant @s only cc:death
