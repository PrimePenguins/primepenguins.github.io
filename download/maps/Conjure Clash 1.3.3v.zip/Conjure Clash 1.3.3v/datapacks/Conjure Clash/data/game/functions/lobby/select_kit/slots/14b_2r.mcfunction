scoreboard players set @s wand.slot.2 2
item replace entity @s enderchest.14 with green_dye{display:{Name:'[{"text":"Platform Wand ","italic":false,"color":"dark_red"},{"text":"- ","color":"blue"},{"text":"\\uE000 ","color":"white"},{"text":"50","color":"blue"}]',Lore:['[{"text":"Summon a platform under you!","italic":false}]']},CustomModelData:6}
clear @s green_dye
title @s actionbar [{"text":"PLATFORM WAND ","color":"red"},{"text":"SELECTED","color":"yellow"}]
tag @s remove random.slot2