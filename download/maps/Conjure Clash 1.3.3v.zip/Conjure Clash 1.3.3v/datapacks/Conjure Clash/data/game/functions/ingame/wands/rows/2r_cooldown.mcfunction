# Rocket Wand
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 1..2 if score @s mana matches 200 run advancement grant @s only cc:costful
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 1..2 if score @s mana matches 200.. run function game:ingame/rocket
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 1..2 if score @s mana matches ..199 run function game:ingame/wands/no_mana
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 1..2 if score @s mana matches ..199 if block ~ ~-1 ~ air run advancement grant @s only cc:problem

# Random Teleport
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 7..8 if score @s mana matches 200 run advancement grant @s only cc:costful
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 7..8 if score @s mana matches 100.. run function game:ingame/wands/wand_effects/random_teleport
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 7..8 if score @s mana matches ..99 run function game:ingame/wands/no_mana

# Platform Wand
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 9..10 if score @s mana matches 50 run advancement grant @s only cc:costful  
execute as @a[scores={extras.wands.detect=1..},nbt={OnGround:0b},tag=!wand.slot.2.cooldown,predicate=!game:prevent_plat_use] at @s if score @s wand.type matches 9..10 if score @s mana matches 50.. run function game:ingame/wands/wand_effects/platform_offfground
execute as @a[scores={extras.wands.detect=1..},nbt={OnGround:1b},tag=!wand.slot.2.cooldown,predicate=!game:prevent_plat_use] at @s if score @s wand.type matches 9..10 if score @s mana matches 50.. run function game:ingame/wands/wand_effects/platform_onground
execute as @a[scores={extras.wands.detect=1..},tag=!wand.slot.2.cooldown] at @s if score @s wand.type matches 9..10 if score @s mana matches ..49 run function game:ingame/wands/no_mana