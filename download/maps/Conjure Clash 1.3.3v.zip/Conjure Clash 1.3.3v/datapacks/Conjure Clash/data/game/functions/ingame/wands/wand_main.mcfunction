execute if score $wand_cooldown main matches 0 run function game:ingame/wands/wand_nocooldown
execute if score $wand_cooldown main matches 1 run function game:ingame/wands/wand_cooldown

# Reset Wand Score
scoreboard players set @a[scores={extras.wands.detect=1..}] extras.wands.detect 0
scoreboard players set @a[scores={ShootDetect=1..}] ShootDetect 0

# Cooldown
scoreboard players add @a[tag=wand.slot.1.cooldown] wand.slot.1.cooldown 1
scoreboard players add @a[tag=wand.slot.2.cooldown] wand.slot.2.cooldown 1
scoreboard players add @a[tag=no.mana] no.mana 1
# Removed Cooldown tag
tag @a[scores={wand.slot.1.cooldown=20..}] remove wand.slot.1.cooldown 
tag @a[scores={wand.slot.2.cooldown=20..}] remove wand.slot.2.cooldown 
tag @a[scores={no.mana=20..}] remove no.mana
# Reset Cooldown score
scoreboard players set @a[tag=!wand.slot.1.cooldown] wand.slot.1.cooldown 0
scoreboard players set @a[tag=!wand.slot.2.cooldown] wand.slot.2.cooldown 0
scoreboard players set @a[tag=!no.mana] no.mana 0

# Get Wand Type 
execute as @a[nbt={SelectedItem:{id:"minecraft:warped_fungus_on_a_stick"}}] at @s store result score @s wand.type run data get entity @s SelectedItem.tag.CustomModelData
function game:ingame/wands/wand_effects/plat_main