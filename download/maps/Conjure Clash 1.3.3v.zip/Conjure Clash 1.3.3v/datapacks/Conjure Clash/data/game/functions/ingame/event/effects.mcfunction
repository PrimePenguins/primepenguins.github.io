execute if score $event main matches 3 run effect give @a[gamemode=!spectator] jump_boost 2 3 true
execute if score $event main matches 4 run effect give @a[gamemode=!spectator] speed 2 3 true
execute if score $event main matches 5 run effect give @a[gamemode=!spectator] minecraft:glowing 1 1 true
execute if score $event main matches 6 run effect give @a[gamemode=!spectator] minecraft:blindness 2 10 true
