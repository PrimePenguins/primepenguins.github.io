scoreboard players reset @s JoinSpec
team leave @s
title @s actionbar [{"text":"You are now a","color":"yellow","bold":true},{"text":" Spectator","color":"gray","bold":true}]
clear @s gray_dye
item replace entity @s container.4 with minecraft:gray_dye{display:{Name:'[{"text":"Spectate ","italic":false,"color":"gray"},{"text":"(Drop)","color":"yellow"}]'},CustomModelData:1}