scoreboard players add @e[tag=plat] plat.time 1
execute as @e[tag=plat,scores={plat.time=0..20}] at @s run fill ~-1 ~-1 ~1 ~1 ~-1 ~-1 green_stained_glass replace air
execute as @e[tag=plat,scores={plat.time=21..40}] at @s run fill ~-1 ~-1 ~1 ~1 ~-1 ~-1 orange_stained_glass replace green_stained_glass
execute as @e[tag=plat,scores={plat.time=41..60}] at @s run fill ~-1 ~-1 ~1 ~1 ~-1 ~-1 red_stained_glass replace orange_stained_glass
execute as @e[tag=plat,scores={plat.time=61..}] at @s run fill ~-1 ~-1 ~1 ~1 ~-1 ~-1 air replace red_stained_glass
kill @e[tag=plat,scores={plat.time=62..}]
execute as @e[tag=plat,predicate=game:prevent_plat_use] at @s run fill ~-1 ~-1 ~1 ~1 ~-1 ~-1 air
kill @e[tag=plat,predicate=game:prevent_plat_use]