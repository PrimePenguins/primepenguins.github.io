# Chromatic Team
tag P2ime add admin
tag teddyishappyl add admin
tag mmooney add admin
tag The_sheep71 add admin
# Friends (ikr i have friends :o)
tag FozzyGozzy add friend
tag Lucuma add friend
tag LunaEclipse4304 add friend
tag Chopper2112 add friend
tag The_Sheep17 add friend
tag wrigglygiggly add friend