scoreboard players set $event_active main 1
title @a actionbar ["",{"text":"EVENTS: ","color":"yellow"},{"text":"ON","color":"green"}]
execute as @e[tag=event_text] run data merge entity @s {text:'[{"text":"EVENTS:","color":"gold","bold":true},{"text":"\\nON","color":"green","bold":true}]'}
scoreboard players display name events info ["",{"text":"EVENTS:","bold":true,"color":"yellow"},{"text":" ON","bold":true,"color":"green"}]

setblock 55 19 -470 spruce_button[facing=north]