fill 12 22 -26 17 75 45 air destroy
fill 12 73 46 83 75 -26 air destroy
fill 78 75 46 83 19 -26 air destroy
fill 83 21 45 11 19 -26 air destroy