scoreboard players set $event main 4
title @a title ["",{"text":"EVENT:","color":"yellow"},{"text":" Speed","color":"blue"}]
title @a subtitle {"text":"Get a Speed Boost!","color":"yellow"}