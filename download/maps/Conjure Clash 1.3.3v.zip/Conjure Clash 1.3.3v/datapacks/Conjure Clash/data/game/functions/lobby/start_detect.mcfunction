execute if score $team1 main matches 1.. if score $team2 main matches 1.. run function game:lobby/start
execute if score $team1 main matches ..0 run title @a actionbar {"text":"Blue Team doesn't have enough players!","bold":true,"italic":true,"color":"blue"}
execute if score $team2 main matches ..0 run title @a actionbar {"text":"Red Team doesn't have enough players!","bold":true,"italic":true,"color":"red"}
execute if score $team1 main matches ..0 if score $team2 main matches ..0 run title @a actionbar {"text":"Not enough players on each teams.","bold":true,"italic":true,"color":"gray"}