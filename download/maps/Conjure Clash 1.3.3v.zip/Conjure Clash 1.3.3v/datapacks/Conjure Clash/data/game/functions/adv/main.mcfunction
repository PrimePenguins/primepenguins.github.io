execute as @a[scores={RocketDetect=1..}] if block ~ ~-1 ~ air if score @s mana matches ..199 run advancement grant @s only cc:problem
execute as @a[predicate=game:star_achiv] run advancement grant @s only cc:star
execute as @a[scores={killcount=1..}] run advancement grant @s only cc:handkill
execute as @a[tag=admin] run advancement grant @a only cc:admin
execute as @a[tag=friend] run advancement grant @a only cc:friend