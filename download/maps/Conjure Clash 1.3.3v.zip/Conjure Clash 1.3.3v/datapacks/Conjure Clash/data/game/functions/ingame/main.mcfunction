# Check Survival
execute store result score $team1 main if entity @a[team=Team1,gamemode=survival]
execute store result score $team2 main if entity @a[team=Team2,gamemode=survival]

# Team Detect Win
execute if score $team1 main matches ..0 if score $team2 main matches 1.. run function game:ingame/end/redwin
execute if score $team2 main matches ..0 if score $team1 main matches 1.. run function game:ingame/end/bluewin
execute if score $team1 main matches ..0 if score $team2 main matches ..0 run function game:ingame/end/tie

# Handels Joining MidGame
tp @a[tag=!check] 45 55 18
gamemode spectator @a[tag=!check]
tag @a[tag=!check] add check

function game:ingame/wands/wand_main
function game:ingame/item
function game:ingame/border

execute as @e[type=item,nbt={Item:{id:"minecraft:carrot_on_a_stick"}}] run data merge entity @s {PickupDelay:0}
execute as @e[type=item,nbt={Item:{id:"minecraft:warped_fungus_on_a_stick"}}] run data merge entity @s {PickupDelay:0}

kill @a[predicate=game:die,gamemode=!spectator]
execute as @a[scores={death=1..}] run function game:ingame/death
tag @a[gamemode=spectator] add death


function game:ingame/mana/mana_main

# Events
execute if score $event_active main matches 1 run scoreboard players add $event_time main 1
execute if score $event_time main matches 1200 run function game:ingame/event/eventmain
execute if score $event_time main matches 2400.. run function game:ingame/event/eventreset
# Jump / Speed
function game:ingame/event/effects

# Odd's Achivement
execute if score $team1 main matches 1 if score $team2 main matches 3 run advancement grant @a[team=Team1,gamemode=survival] only cc:odds
execute if score $team1 main matches 3 if score $team2 main matches 1 run advancement grant @a[team=Team2,gamemode=survival] only cc:odds
