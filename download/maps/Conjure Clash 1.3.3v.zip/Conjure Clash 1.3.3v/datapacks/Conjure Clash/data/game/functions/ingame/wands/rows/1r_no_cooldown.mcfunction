execute as @a[scores={ShootDetect=1..}] at @s if score @s mana matches 20 run advancement grant @s only cc:costful
execute as @a[scores={ShootDetect=1..}] at @s if score @s mana matches 20.. anchored eyes positioned ^ ^ ^ anchored feet run function tnt1:start_ray
execute as @a[scores={ShootDetect=1..}] at @s if score @s mana matches ..19 run function game:ingame/wands/no_mana

# Bomb Wand
execute as @a[scores={extras.wands.detect=1..}] at @s if score @s wand.type matches 3..4 if score @s mana matches 100 run advancement grant @s only cc:costful
execute as @a[scores={extras.wands.detect=1..}] at @s if score @s wand.type matches 3..4 if score @s mana matches 100.. anchored eyes positioned ^ ^ ^ anchored feet run function bomb:start_ray
execute as @a[scores={extras.wands.detect=1..}] at @s if score @s wand.type matches 3..4 if score @s mana matches ..99 run function game:ingame/wands/no_mana

# Scatter Wand
execute as @a[scores={extras.wands.detect=1..}] at @s if score @s wand.type matches 5..6 if score @s mana matches 100 run advancement grant @s only cc:costful
execute as @a[scores={extras.wands.detect=1..}] at @s if score @s wand.type matches 5..6 if score @s mana matches 100.. run function game:ingame/wands/wand_effects/scatter
execute as @a[scores={extras.wands.detect=1..}] at @s if score @s wand.type matches 5..6 if score @s mana matches ..99 run function game:ingame/wands/no_mana
