execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:paper",Slot:2b}]}] run clear @s paper
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:paper",Slot:11b}]}] run clear @s paper
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:paper",Slot:2b}]}] run item replace entity @s enderchest.2 with paper{display:{Name:'{"text":"Explosive Wands","color":"dark_red","bold":true,"italic":true}'}}
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:paper",Slot:11b}]}] run item replace entity @s enderchest.11 with paper{display:{Name:'{"text":"Jump Wands","color":"dark_red","bold":true,"italic":true}'}}
# First Row / First Slot
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:3b}]}] run function game:lobby/select_kit/slots/3b_1r
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:4b}]}] run function game:lobby/select_kit/slots/4b_1r
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:5b}]}] run function game:lobby/select_kit/slots/5b_1r
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:6b}]}] run function game:lobby/select_kit/slots/randomize_slot1
scoreboard players set @a[scores={wand.slot.1=4..}] wand.slot.1 3
# Second Row / Second Slot
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:12b}]}] run function game:lobby/select_kit/slots/12b_2r
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:13b}]}] run function game:lobby/select_kit/slots/13b_2r
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:14b}]}] run function game:lobby/select_kit/slots/14b_2r
execute as @a unless entity @s[nbt={EnderItems:[{id:"minecraft:green_dye",Slot:15b}]}] run function game:lobby/select_kit/slots/randomize_slot2
scoreboard players set @a[scores={wand.slot.2=4..}] wand.slot.2 3

function game:lobby/select_kit/glass_protect