execute store result score $event main run random value 1..6
execute if score $event main matches 1 run function game:ingame/event/event_text/2x_mana
execute if score $event main matches 2 run function game:ingame/event/event_text/faster_fuse
execute if score $event main matches 3 run function game:ingame/event/event_text/jumpy
execute if score $event main matches 4 run function game:ingame/event/event_text/sped
execute if score $event main matches 5 run function game:ingame/event/event_text/glow
execute if score $event main matches 6 run function game:ingame/event/event_text/blind