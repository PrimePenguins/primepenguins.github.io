fill 70 20 -491 69 19 -491 barrier
fill 69 20 -492 69 19 -494 barrier
fill 69 20 -495 70 19 -495 barrier
fill 59 20 -473 48 19 -473 barrier
fill 53 26 -494 51 25 -494 barrier
tellraw @a ["",{"text":"Settings have been locked by ","color":"red"},{"selector":"@s","color":"yellow"}]