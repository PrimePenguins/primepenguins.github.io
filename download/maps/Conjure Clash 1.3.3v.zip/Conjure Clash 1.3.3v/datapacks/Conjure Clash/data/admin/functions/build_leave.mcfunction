tag @s remove build
tag @s remove check
clear @s
