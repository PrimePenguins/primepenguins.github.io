tag @s add build
tp @s 254 93 -99862
clear @s
gamemode creative @s