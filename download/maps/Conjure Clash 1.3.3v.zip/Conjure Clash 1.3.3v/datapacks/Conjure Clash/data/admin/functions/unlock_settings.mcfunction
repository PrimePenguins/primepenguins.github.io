fill 70 20 -491 69 19 -491 air
fill 69 20 -492 69 19 -494 air
fill 69 20 -495 70 19 -495 air
fill 59 20 -473 48 19 -473 air
fill 53 26 -494 51 25 -494 air
tellraw @a ["",{"text":"Settings have been unlocked by ","color":"red"},{"selector":"@s","color":"yellow"}]