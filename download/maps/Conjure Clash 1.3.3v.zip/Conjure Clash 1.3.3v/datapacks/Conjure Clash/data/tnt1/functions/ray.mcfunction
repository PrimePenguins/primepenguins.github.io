#Running custom per-step commands.

particle dust 1.000 0.000 0.000 1 ~ ~ ~ 0 0 0 0 0 normal

#Check if an entity was detected.

execute if score #hit tnt1 matches 0 positioned ~-0.05 ~-0.05 ~-0.05 as @e[type=#game:entities,tag=!tnt1,dx=0,sort=nearest] run function tnt1:check_hit_entity

#Run a function if a block was successfully detected.

execute unless block ~ ~ ~ #game:blocks run function tnt1:tnt
scoreboard players add #distance tnt1 1

#Advance forward and run the ray again if no entity and/or block was found.

execute if score #hit tnt1 matches 0 if score #distance tnt1 matches ..550 positioned ^ ^ ^0.1 run function tnt1:ray