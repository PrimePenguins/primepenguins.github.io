scoreboard players set #hit tnt1 1

execute if score $event main matches 0..1 run summon tnt ~ ~ ~ {fuse:20,NoGravity:1b}
execute if score $event main matches 2 run summon tnt ~ ~ ~ {fuse:10,NoGravity:1b}
execute if score $event main matches 3.. run summon tnt ~ ~ ~ {fuse:20,NoGravity:1b}